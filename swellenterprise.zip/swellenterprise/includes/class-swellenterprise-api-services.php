<?php
/**
 * Integrate with SWELLEnterprise API
 *
 * @link       http://joe.szalai.org
 * @since      1.0.0
 *
 * @package    Exopite_Portfolio
 * @subpackage Exopite_Portfolio/includes
 */
class SWELLEnterprise_API_Services {

	protected $leads, $contacts, $clients;
		
    public function __construct($leads = null, $contacts = null, $clients = null, $options = null) {

        $this->options = $options;
        $this->leads = $leads;
		$this->clients = $clients;
		$this->contacts = $contacts;
    }

    public function check_if_post_exists($post_type, $key = 'hash_id', $value){
        $args = array('post_type' => $post_type, 'meta_key' => $key, 'meta_value' => $value);
        $posts = get_posts($args);
        if (empty($posts)){
            return 0;
        } else {
            return $posts[0]->ID;
        }
    }

    
    private function authenticate_swell_request($method, $endpoint){

        try {

            if(!isset($this->options) || empty($this->options))

            $this->options = get_exopite_sof_option( 'swellenterprise' );

        } catch (HttpException $httpException) {

            $this->swell_admin_notice('danger', 'There is an error: Not Authorized' );
        }

			$url = 'https://app.swellsystem.com/api/v2/' . $endpoint;

            $transient_prefix = esc_attr($method . $endpoint);

            $transient = get_transient('swellenterprise-' . $transient_prefix);
        	
            if( !empty( $transient ) ) {
                //Already have the transient so fetch that instead
                return $transient;

            } else {
                //No transient so call the API and create one
                
                $wp_request_headers = array(
                    'Content-type' => 'application/json',
                    'Authorization' => 'Basic ' . base64_encode( $this->options['username'] . ':' . $this->options['password'] )
                );
                
                $response = wp_remote_request(
                    $url,
                    array(
                          'method' => $method,
                          'headers'   => $wp_request_headers,
                    )
                );

                if(wp_remote_retrieve_response_code( $response ) === 200){
                    $response_body = wp_remote_retrieve_body($response);
                    set_transient('swellenterprise-' . $transient_prefix, $response_body, apply_filters('null_swellenterprise_cache_time', HOUR_IN_SECONDS * 2));
                    return $response_body;

                } else {
                        
        //           $this->swell_admin_notice('danger', 'There is an error: ' . wp_remote_retrieve_response_message( $response ));
                }
            }
//        var_dump($this->options['password']);


    }
    private function register_swell_webhook($method, $event, $url){

        try {

            if(!isset($this->options) || empty($this->options))

                $this->options = get_exopite_sof_option( 'swellenterprise' );

        } catch (HttpException $httpException) {

            $this->swell_admin_notice('danger', 'There is an error: Not Authorized' );
        }

        $endpoint = 'https://app.swellsystem.com/api/subscribe';

            //No transient so call the API and create one

            $wp_request_headers = array(
                'Content-type' => 'application/json',
                'Authorization' => 'Basic ' . base64_encode( $this->options['username'] . ':' . $this->options['password'] )
            );

            $response = wp_remote_request(
                $endpoint,
                array(
                    'method' => $method,
                    'headers'   => $wp_request_headers,
                    'body'        => array(
                        'url' => $url,
                        'event' => $event
                    ),
                )
            );

            if(wp_remote_retrieve_response_code( $response ) === 200){
                $response_body = wp_remote_retrieve_body($response);
                return $response_body;

            } else {

                //$this->swell_admin_notice('danger', 'There is an error: ' . wp_remote_retrieve_response_message( $response ));
            }
//        var_dump($this->options['password']);


    }

    public function get_contacts(){
       
		if($this->options['contact_switcher'] === 'yes') {
			
			$contacts = $this->authenticate_swell_request('GET', 'contacts');       
			
			if(!empty($contacts)) {
				
				$this->contacts = json_decode($contacts, true);
			
			} else {

			    $this->swell_admin_notice('danger', 'There is an error getting your contacts');
			} 
		} else {
			
//			$this->swell_admin_notice('danger', 'Contacts is turned off in your settings.');
		}

    }

    public function create_contact($contact = NULL, $post_id = 0){

            $args = array(
                'ID'    =>  $post_id,
                'post_status'   => 'publish',
                'post_type' =>  'contact',
                'post_title' => $contact['first_name'] . ' ' . $contact['last_name'] . ' - ' . $contact['organization'],
                'meta_input' => array(
                    'email' => $contact['email'],
                    'phone_number' => $contact['phone_number'],
                    'address' => $contact['address'],
                    'city' => $contact['city'],
                    'state' => $contact['state'],
                    'zip' => $contact['zip'],
                    'hash_id' => $contact['id'],
                ),
            );

            $post = wp_insert_post($args);

            update_post_meta( $post, 'first_name', $contact['first_name'] );
            update_post_meta( $post, 'last_name', $contact['last_name'] );
            update_post_meta( $post, 'organization', $contact['organization'] );
            update_post_meta( $post, 'email', $contact['email'] );
            update_post_meta( $post, 'phone_number', $contact['phone_number'] );
            update_post_meta( $post, 'address', $contact['address'] );
            update_post_meta( $post, 'city', $contact['city'] );
            update_post_meta( $post, 'state', $contact['state'] );
            update_post_meta( $post, 'zip', $contact['zip'] );
            update_post_meta( $post, 'hash_id', $contact['id'] );

            if(!empty($contact['tags'])) {
                foreach($contact['tags'] as $tag) {
                    wp_set_object_terms( $post, $tag['label'], 'contact_tag', false );
                }
            }

            /*if(array_key_exists('field', $contact)) {
                update_post_meta( $post, $contact['field'], $contact['value'] );
            }*/
    }

    /*
    just keeping for reference, dont need this I dont think
     public function update_contact($contact, $post_id = NULL){

            $args = array(
                'ID' => $post_id,
                'post_status'   => 'publish',
                'post_type' =>  'contact',
                'post_title' => $contact['first_name'] . ' ' . $contact['last_name'] . ' - ' . $contact['organization'],
                'meta_input' => array(
                    'email' => $contact['email'],
                    'phone' => $contact['phone_number'],
                    'address' => $contact['address'],
                    'city' => $contact['city'],
                    'state' => $contact['state'],
                    'zip' => $contact['zip'],
                    'hash_id' => $contact['id'],
                ),
            );

            wp_update_post($args);
    }*/

    
    public function sync_contacts(){
		
		$this->get_contacts();

        if(isset($this->contacts)){
            foreach($this->contacts as $contact){
                if(isset($contact['id'])){ //check the key exists in the array
                    if($this->check_if_post_exists('contact', 'hash_id', $contact['id']) === 0){
                        $this->create_contact($contact);
                    } else {
                        $id = $this->check_if_post_exists('contact', 'hash_id', $contact['id']);
                        $this->create_contact($contact, $id);
                    }
                }
            }
        }
    }

    public function get_clients(){
		
        $clients = $this->authenticate_swell_request('GET', 'clients');
		
		if ($this->options['client_switcher'] === 'yes') {
			
			if(!empty($clients)) {
				$this->clients = json_decode($clients, true);
			} else {
				$this->swell_admin_notice('danger', 'There is an error:' . $clients);
			}
		} else {
//			$this->swell_admin_notice('danger', 'Clients is turned off in your settings.');
		}	
	
    }

    public function create_client($client = NULL, $post_id = 0){

            $args = array(
                'ID'    =>  $post_id,
                'post_status'   => 'publish',
                'post_type' =>  'client',
                'post_title' => $client['first_name'] . ' ' . $client['last_name'] . ' - ' . $client['organization'],
                'meta_input' => array(
                    'email' => $client['email'],
                    'phone_number' => $client['phone_number'],
                    'address' => $client['address'],
                    'city' => $client['city'],
                    'state' => $client['state'],
                    'zip' => $client['zip'],
                    'hash_id' => $client['id'],
                ),
            );

            $post = wp_insert_post($args);

            update_post_meta( $post, 'first_name', $client['first_name'] );
            update_post_meta( $post, 'last_name', $client['last_name'] );
            update_post_meta( $post, 'organization', $client['organization'] );
            update_post_meta( $post, 'email', $client['email'] );
            update_post_meta( $post, 'phone_number', $client['phone_number'] );
            update_post_meta( $post, 'address', $client['address'] );
            update_post_meta( $post, 'city', $client['city'] );
            update_post_meta( $post, 'state', $client['state'] );
            update_post_meta( $post, 'zip', $client['zip'] );
            update_post_meta( $post, 'hash_id', $client['id'] );

            if(array_key_exists('field', $client)) {
                update_post_meta( $post, $client['field'], $client['value'] );
            }

            if(!empty($client['tags'])) {
                foreach($client['tags'] as $tag) {
                    wp_set_object_terms( $post, $tag['label'], 'client_tag', false );
                }
            }
			
		if(!empty($client['notes'])) {
				foreach($client['notes'] as $note) {
					if($this->check_if_post_exists('note', 'hash_id', $note['id']) === 0){
                        $this->create_note($note, 'client',  $client['id'] , 0);
                    } else {
                        $id = $this->check_if_post_exists('note', 'hash_id', $note['id']);
                        $this->create_note($note, 'client',  $client['id'] , $id);
                    }

				}
			}
    }

    public function sync_clients(){
        
		$this->get_clients();
	
        if(isset($this->clients)){
            foreach($this->clients as $client){
                if(isset($client['id'])){ //check the key exists in the array
                    if($this->check_if_post_exists('client', 'hash_id', $client['id']) === 0){
                        $this->create_client($client);
                    } else {
                        $id = $this->check_if_post_exists('client', 'hash_id', $client['id']);
                        $this->create_client($client,$id);
                    }
                }
            }
        }
    }

    public function get_leads(){
		if ($this->options['lead_switcher'] === 'yes') {
        
			$leads = $this->authenticate_swell_request('GET', 'leads');

        if(!empty($leads)) {
			
			$this->leads = json_decode($leads, true);
		
		} else {
			
			$this->swell_admin_notice('danger', 'There is an error:' . $leads);
	
		}
		
		} else {
//			$this->swell_admin_notice('danger', 'Leads is turned off in your settings.');
		}
        $this->closeConnection();

    }

    public function create_lead($lead = NULL, $post_id = 0){

            $args = array(
                'ID'    =>  $post_id,
                'post_status'   => 'publish',
                'post_type' =>  'lead',
                'post_title' => $lead['first_name'] . ' ' . $lead['last_name'] . ' - ' . $lead['organization'],
                'meta_input' => array(
                    'email' => $lead['email'],
                    'phone_number' => $lead['phone_number'],
                    'address' => $lead['address'],
                    'city' => $lead['city'],
                    'state' => $lead['state'],
                    'zip' => $lead['zip'],
                    'hash_id' => $lead['id'],
                ),
            );

            $post = wp_insert_post($args);

            update_post_meta( $post, 'first_name', $lead['first_name'] );
            update_post_meta( $post, 'last_name', $lead['last_name'] );
            update_post_meta( $post, 'organization', $lead['organization'] );
            update_post_meta( $post, 'email', $lead['email'] );
            update_post_meta( $post, 'phone_number', $lead['phone_number'] );
            update_post_meta( $post, 'address', $lead['address'] );
            update_post_meta( $post, 'city', $lead['city'] );
            update_post_meta( $post, 'state', $lead['state'] );
            update_post_meta( $post, 'zip', $lead['zip'] );
            update_post_meta( $post, 'hash_id', $lead['id'] );

            if(array_key_exists('field', $lead)) {
                update_post_meta( $post, $lead['field'], $lead['value'] );
            }

			if(isset($lead['status']['label'])) wp_set_object_terms( $post, $lead['status']['label'], 'lead_status', false );

			if(!empty($lead['tags'])) {
				foreach($lead['tags'] as $tag) {
					wp_set_object_terms( $post, $tag['label'], 'lead_tag', false );
				}
			}
		
		if(!empty($lead['notes'])) {
// 			var_dump($lead['notes']);
				foreach($lead['notes'] as $note) {
					if($this->check_if_post_exists('note', 'hash_id', $note['id']) === 0){
                        $this->create_note($note, 'lead',  $lead['id'] , 0);
                    } else {
                        $id = $this->check_if_post_exists('note', 'hash_id', $note['id']);
                        $this->create_note($note, 'lead',  $lead['id'] , $id);
                    }

				}
			}
		if(!empty($lead['tasks'])) {
				foreach($lead['tasks'] as $task) {
					if($this->check_if_post_exists('task', 'hash_id', $task['id']) === 0){
                        $this->create_task($task, 'lead',  $lead['id'] , 0);
                    } else {
                        $id = $this->check_if_post_exists('task', 'hash_id', $task['id']);
                        $this->create_task($task, 'lead',  $lead['id'] , $id);
                    }

				}
			}
    }

    public function sync_leads(){
       $this->get_leads();
        if(isset($this->leads)){
            foreach($this->leads as $lead){
                if(isset($lead['id'])){ //check the key exists in the array
                    if($this->check_if_post_exists('lead', 'hash_id', $lead['id']) === 0){
                        $this->create_lead($lead);
                    } else {
                        $id = $this->check_if_post_exists('lead', 'hash_id', $lead['id']);
                        $this->create_lead($lead, $id);
                    }
                }
            }
        }
    }
    
//     public function get_extras($model, $id){
        
//         $endpoint = $model . "/" . $id . "/extras";
//         return $this->authenticate_swell_request('GET', $endpoint);
       
//     }

// 	public function create_note($note = NULL, $relation, $post_id = 0){

    public function create_note($note, $relation = null, $relation_id = null,$post_id = 0){

	       //add if ($this->options['note_switcher'] === 'yes') {
            $note_args = array(
                'ID'    =>  $post_id,
                'post_status'   => 'publish',
                'post_type' =>  'note',
                'post_title' => $note['title'],
                'post_content' => $note['description'],
            );

            $thisNote = wp_insert_post($note_args);

            update_post_meta( $thisNote, 'author', $note['author'] );
//             update_post_meta( $thisNote, 'avatar_url', $note['user']['avatar_url'] );
            update_post_meta( $thisNote, 'created_at', $note['created_at'] );
//             update_post_meta( $thisNote, 'updated_at', $note['updated_at'] );
            update_post_meta( $thisNote, 'hash_id', $note['id'] );
            update_post_meta( $thisNote, $relation . '_id', $relation_id );
    }
	
    public function create_task($task, $relation = null, $relation_id = null,$post_id = 0){

		//add if ($this->options['task_switcher'] === 'yes') {
            $task_args = array(
                'ID'    =>  $post_id,
                'post_status'   => 'publish',
                'post_type' =>  'task',
                'post_title' => $task['title'],
                'post_content' => $task['description'],
            );

            $thisTask = wp_insert_post($task_args);

//             update_post_meta( $thisTask, 'author', $task['author'] );
//             update_post_meta( $thisNote, 'avatar_url', $note['user']['avatar_url'] );
//             update_post_meta( $thisTask, 'created_at', $task['created_at'] );
//             update_post_meta( $thisNote, 'updated_at', $note['updated_at'] );
//             update_post_meta( $thisTask, 'hash_id', $task['hash_id'] );
            update_post_meta( $thisTask, $relation . '_id', $relation_id );
    }


    public function swell_admin_notice($type = NULL, $message = NULL){
        global $pagenow;

        if ( $pagenow == 'options-general.php' ) {

        if($type !== NULL && $message !== NULL){
             echo '<div class="notice notice-' . $type . ' is-dismissible">
                 <p>' . $message . '</p>
                 <button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>
             </div>';

         }

        }
    }
    public function swellWebhooks($method, $endpoint, $url, $event)
    {
        $clients = $this->register_swell_webhook('POST', 'subscribe', $event);


    }
    public function closeConnection()
    {
        return new WP_REST_Response('success', 200);

    }

}