<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    SWELLEnterprise
 * @subpackage SWELLEnterprise/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    SWELLEnterprise
 * @subpackage SWELLEnterprise/includes
 * @author     Your Name <email@example.com>
 */
class SWELLEnterprise_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
		/**
	     * This only required if custom post type has rewrite!
	     */
	    flush_rewrite_rules();
	}

}
