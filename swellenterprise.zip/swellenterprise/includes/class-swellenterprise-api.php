<?php
/**
 * Integrate with SWELLEnterprise API
 *
 * @link       http://joe.szalai.org
 * @since      1.0.0
 *
 * @package    Exopite_Portfolio
 * @subpackage Exopite_Portfolio/includes
 */
class SWELLEnterprise_API {

	protected $leads, $contacts, $clients;
		
    public function __construct($leads = null, $contacts = null, $clients = null, $options = null) {

        $this->options = $options;
        $this->leads = $leads;
		$this->clients = $clients;
		$this->contacts = $contacts;
    }
    
    private function authenticate_swell_request($method, $endpoint){

        try {

            if(!isset($this->options) || empty($this->options))

            $this->options = get_exopite_sof_option( 'swellenterprise' );

        } catch (HttpException $httpException) {

            $this->swell_admin_notice('danger', 'There is an error: Not Authorized' );
        }

			$url = 'https://app.swellsystem.com/api/v2/' . $endpoint;

            $transient_prefix = esc_attr($method . $endpoint);

            $transient = get_transient('swellenterprise-' . $transient_prefix);
        	
            if( !empty( $transient ) ) {
                //Already have the transient so fetch that instead
                return $transient;

            } else {
                //No transient so call the API and create one
                
                $wp_request_headers = array(
                    'Content-type' => 'application/json',
                    'Authorization' => 'Basic ' . base64_encode( $this->options['username'] . ':' . $this->options['password'] )
                );
                
                $response = wp_remote_request(
                    $url,
                    array(
                          'method' => $method,
                          'headers'   => $wp_request_headers,
                    )
                );

                if(wp_remote_retrieve_response_code( $response ) === 200){
                    $response_body = wp_remote_retrieve_body($response);
                    set_transient('swellenterprise-' . $transient_prefix, $response_body, apply_filters('null_swellenterprise_cache_time', HOUR_IN_SECONDS * 2));
                    return $response_body;

                } else {
                        
        //           $this->swell_admin_notice('danger', 'There is an error: ' . wp_remote_retrieve_response_message( $response ));
                }
            }
//        var_dump($this->options['password']);


    }
    private function register_swell_webhook($method, $event, $url){

        try {

            if(!isset($this->options) || empty($this->options))

                $this->options = get_exopite_sof_option( 'swellenterprise' );

        } catch (HttpException $httpException) {

            $this->swell_admin_notice('danger', 'There is an error: Not Authorized' );
        }

        $endpoint = 'https://app.swellsystem.com/api/subscribe';

            //No transient so call the API and create one

            $wp_request_headers = array(
                'Content-type' => 'application/json',
                'Authorization' => 'Basic ' . base64_encode( $this->options['username'] . ':' . $this->options['password'] )
            );

            $response = wp_remote_request(
                $endpoint,
                array(
                    'method' => $method,
                    'headers'   => $wp_request_headers,
                    'body'        => array(
                        'url' => $url,
                        'event' => $event
                    ),
                )
            );

            if(wp_remote_retrieve_response_code( $response ) === 200){
                $response_body = wp_remote_retrieve_body($response);
                return $response_body;

            } else {

                //$this->swell_admin_notice('danger', 'There is an error: ' . wp_remote_retrieve_response_message( $response ));
            }
//        var_dump($this->options['password']);
        $this->closeConnection();


    }

    private function delete_swell_webhook($id){

        try {

            if(!isset($this->options) || empty($this->options))

                $this->options = get_exopite_sof_option( 'swellenterprise' );

        } catch (HttpException $httpException) {

            $this->swell_admin_notice('danger', 'There is an error: Not Authorized' );
        }

        $endpoint = 'https://app.swellsystem.com/api/subscribe/'.$id;

        //No transient so call the API and create one

        $wp_request_headers = array(
            'Content-type' => 'application/json',
            'Authorization' => 'Basic ' . base64_encode( $this->options['username'] . ':' . $this->options['password'] )
        );

        $response = wp_remote_request(
            $endpoint,
            array(
                'method' => 'DELETE',
                'headers'   => $wp_request_headers
            )
        );

        if(wp_remote_retrieve_response_code( $response ) === 200){

            $response_body = wp_remote_retrieve_body($response);

            return $response_body;

        } else {

            //$this->swell_admin_notice('danger', 'There is an error: ' . wp_remote_retrieve_response_message( $response ));
        }
        $this->closeConnection();

    }


    public function init_services()
    {

        if(isset($this->options['contact_switcher']) && $this->options['contact_switcher'] === 'yes') {

            $contacts = $this->authenticate_swell_request('GET', 'contacts');

            if(!empty($contacts)) {

                $this->contacts = json_decode($contacts, true);

                $this->init_contact_service();

            } else {

                $this->swell_admin_notice('danger', 'There is an error getting your contacts');
            }


        } else {

//			$this->swell_admin_notice('danger', 'Contacts is turned off in your settings.');
        }

        if (isset($this->options['lead_switcher']) && $this->options['lead_switcher'] === 'yes') {

            $leads = $this->authenticate_swell_request('GET', 'leads');

            if(!empty($leads)) {

                $this->leads = json_decode($leads, true);
                $this->init_lead_service();

            } else {

                $this->swell_admin_notice('danger', 'There is an error:' . $leads);

            }

        } else {
//			$this->swell_admin_notice('danger', 'Leads is turned off in your settings.');
        }

        if (isset($this->options['client_switcher']) && $this->options['client_switcher'] === 'yes') {

            $clients = $this->authenticate_swell_request('GET', 'clients');

            if(!empty($clients)) {
                $this->clients = json_decode($clients, true);

                $this->init_client_service();

            } else {
                $this->swell_admin_notice('danger', 'There is an error:' . $clients);
            }
        } else {
//			$this->swell_admin_notice('danger', 'Clients is turned off in your settings.');
        }

        $this->closeConnection();

    }


    public function init_contact_service()
    {
        //$this->register_swell_webhook($method, $event, $url);

    }

    public function init_lead_service()
    {
        //$this->register_swell_webhook($method, $event, $url);

    }
    public function init_client_service()
    {
        //$this->register_swell_webhook($method, $event, $url);

    }
    

    public function swell_admin_notice($type = NULL, $message = NULL){
        global $pagenow;

        if ( $pagenow == 'options-general.php' ) {

        if($type !== NULL && $message !== NULL){
             echo '<div class="notice notice-' . $type . ' is-dismissible">
                 <p>' . $message . '</p>
                 <button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>
             </div>';

         }

        }
    }
    public function swellWebhooks($method, $endpoint, $url, $event)
    {
        //$clients = $this->register_swell_webhook('POST', 'subscribe', $event);

    }
    public function closeConnection()
    {
        return new WP_REST_Response('success', 200);

    }

}